#include<iostream>
using namespace std;
//task 1
template<typename t>
class list {
protected:
	t* arr;
	int maxsize;
	int currentsize;
public:
	virtual t removeElementFromSpecificPositionList(int pos) = 0;
	virtual void firstRepeatingElement() = 0;
	virtual void firstNonRepeatingElement() = 0;
	virtual void findPairs(t) = 0;
};

//task 2
template<typename t>
class mylist :public list<t> {
public:
	mylist() {
		this->maxsize = 10;
		this->currentsize = -1;
		this->arr = new t[this->maxsize];
	}

	void insert(t value) {
		this->currentsize++;
		if (this->currentsize < this->maxsize) {
			this->arr[this->currentsize] = value;
		}
		else {
			cout << "\n cannot add any more elemnet";
		}
	}
	t removeElementFromSpecificPositionList(int pos)override {
		bool chk = true;
		for (int i = 0; i <= this->currentsize; i++) {
			if (i == pos - 1) {
				int num = this->arr[i];
				for (int j = i; j < this->currentsize; j++) {

					this->arr[j] = this->arr[j + 1];
					chk = true;
				}
				return num;

			}
		}
		return -1;
	}
	void firstRepeatingElement()override {
		bool chk = true;
		for (int i = 0; i < this->currentsize; i++) {
			for (int j = i + 1; j < this->currentsize; j++) {
				if (this->arr[i] == this->arr[j]) {
					cout << "\nfrist repeating element is : " << this->arr[i];
					chk = false;
					break;
				}
			}
		}
		if (chk) {
			cout << "\nall elements are unique ";
		}

	}
	void firstNonRepeatingElement()override {
		bool chk = true;
		for (int i = 0; i <= this->currentsize; i++) {
			chk = true;
			for (int j = i + 1; j <= this->currentsize; j++) {
				if (this->arr[i] == this->arr[j]) {
					chk = false;
					break;
				}
			}
			if (chk) {
				cout << "\nfirst non repeating element is : " << this->arr[i];
				chk = false;
			}
		}
		if (!chk) {
			cout << "\nno unique elements.";
		}
	}
	void findPairs(t val)override {
		cout << "\npairs whoes sum is equal to" << val << " are : ";
		bool chk = true;
		for (int i = 0; i <= this->currentsize; i++) {
			for (int j = i + 1; j <= this->currentsize; j++) {
				if (this->arr[i] + this->arr[j] == val) {
					cout << "(" << this->arr[i] << "," << this->arr[j] << ") ,";
					chk = false;
				}
			}
		}
		if (!chk) {
			cout << "\nnone";
		}
	}
	void freqOfEachElement() {
		t* arr2 = new t[this->currentsize + 1];
		int count = 1;
		for (int i = 0; i <= this->currentsize; i++) {
			count = 1;
			for (int j = i + 1; j <= this->currentsize; j++) {
				if (this->arr[i] == this->arr[j]) {
					count++;
					arr2[j] = 1;
				}
			}
			if (arr2[i] != 1) {
				cout << "\nfrequency of " << this->arr[i] << " is : " << count;
			}
		}
	}
	void leftrotate(int pos) {
		for (int i = 0; i <= this->currentsize; i++) {
			if (i + pos > this->currentsize) {
				this->currentsize = i;
				break;
			}
			this->arr[i] = this->arr[i + pos];

		}
	}
	void rightrotate(int pos) {
		for (int i = this->currentsize; i > 0; i--) {
			if (i - pos < 0) {
				break;
			}
			this->arr[i] = this->arr[i - pos];

		}
		for (int i = 0; i < pos; i++) {
			this->arr[i] = -999;
		}
	}
	//task 3
	void missingnumber(t* arr, int size) {
		for (int i = 0; i < size; i++) {
			if (arr[i] != i) {
				cout << "\n" << i << " is missing.";
			}
		}
	}
	void displayElements() {
		for (int i = 0; i < this->currentsize; i++) {
			cout << "\n" << this->arr[i] << " ";
		}
	}
	~mylist() {
		delete[]this->arr;
	}
};
int main()
{
	mylist<int> l;
	l.insert(1);
	l.insert(2);
	l.insert(3);
	l.insert(4);
	l.insert(1);
	cout << "\narray is : ";
	l.displayElements();
	//nonrepeating element
	l.firstNonRepeatingElement();
	//repeating element
	l.firstRepeatingElement();
	//pairs finding of 2
	l.findPairs(2);
	//frequency of each element
	l.freqOfEachElement();
	//removing element from specific position
	int num = l.removeElementFromSpecificPositionList(5);
	if (num == -1) {
		cout << "\nposition 5 does not exit";
	}
	else {
		cout << num << " removed from position 5";
		cout << "\nupdated list : ";
		l.displayElements();
	}
	l.leftrotate(1);
	cout << "\nlist after left rotation of 1 postion : ";
	l.displayElements();
	cout << "\nlist after right rotation of 1 postion : ";
	l.rightrotate(1);
	l.displayElements();

}
