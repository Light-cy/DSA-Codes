#include<iostream>
#include<vector>
using namespace std;
//task 1
template<typename t>
class list {
protected:
	t* arr;
	int maxsize;
	int currentsize;
public:
	virtual vector<t> arrayIntersection(t* arr2, int size) = 0;
	virtual int findSubArray(t* subarr, int size) = 0;
	virtual void LongestEqualBinary() = 0;
};

template<typename t>
class mylist :public list<t> {
public:
	mylist() {
		this->maxsize = 10;
		this->currentsize = -1;
		this->arr = new t[this->maxsize];
	}

	void insert(t value) {
		this->currentsize++;
		if (this->currentsize < this->maxsize) {
			this->arr[this->currentsize] = value;
		}
		else {
			cout << "\n cannot add any more elemnet";
		}
	}
	vector<t> arrayIntersection(t* arr2, int size) {

		vector<t> intersected_elements(0);
		int min = 0;
		if (this->currentsize < size) {
			min = size;
		}
		else {
			min = this->currentsize + 1;
		}
		for (int i = 0; i < min; i++) {
			if (this->arr[i] == arr2[i]) {
				intersected_elements.push_back(this->arr[i]);
			}
		}
		return intersected_elements;
	}
	int findSubArray(t* subarr, int size) {
		int count = 1;
		for (int i = 0; i <= this->currentsize; i++) {
			if (this->arr[i] == subarr[0]) {
				count = 1;
				for (int j = 1; j < size; j++) {
					if (this->arr[i + j] != subarr[j]) {
						break;
					}
					count++;
				}
				if (count == size) {
					return 1;
				}
			}
		}
		return 0;
	}
	void LongestEqualBinary() {
		int count0 = 0, count1 = 0, count = 0;
		for (int i = 0; i <= this->currentsize; i++) {
			if (this->arr[i] == 0) {
				count0++;
			}
			else {
				count1++;
			}
		}
		int size = 0;
		int num = 0;
		int numcount = 0, largecount = 0;
		if (count0 > count1) {
			size = 2 * count1;
			num = 1;
			largecount = count1;
		}
		else {
			size = 2 * count0;
			num = 0;
			largecount = count0;
		}
		cout << "\nlongest equal binary subarray is of length : " << size;
	}
	//task 2
	void primecount() {
		int count = 0;
		bool chk = true;
		cout << "\nprime numbers are : ";
		for (int i = 0; i <= this->currentsize; i++) {
			count = 0;
			for (int j = 2; j < this->arr[i]; j++) {
				if (this->arr[i] % j == 0) {
					count++;
					break;
				}
			}
			if (!count) {
				cout << this->arr[i] << " ";
				chk = false;
			}
		}
		if (chk) {
			cout << "\n no prime numbers are there.";
		}
	}
	vector<t> distintPrime() {
		vector<t> freq(this->currentsize + 1, 0);
		vector<t>prime(0);
		int count = 0;
		for (int i = 0; i <= this->currentsize; i++) {
			count = 0;
			if (freq[i] != 1) {
				for (int j = 2; j < i; j++) {
					if (this->arr[i] % j == 0) {
						count++;
						break;
					}
				}
				if (!count) {
					prime.push_back(this->arr[i]);
				}
				for (int j = i + 1; j <= this->currentsize; j++) {
					if (this->arr[i] == this->arr[j]) {
						freq[j] = 1;
					}
				}
			}
		}
		return prime;
	}
	void displayElements() {
		for (int i = 0; i <= this->currentsize; i++) {
			cout << this->arr[i] << " ";
		}
	}
	~mylist() {
		delete[]this->arr;
	}
};
int main()
{
	mylist<int> l;
	l.insert(1);
	l.insert(2);
	l.insert(3);
	l.insert(4);
	l.insert(1);
	int arr[5] = { 1,2,3,5,6 };

	////intersection
	cout << "\n\nintersectoin part : \n";
	cout << "\noriginal array is : ";
	l.displayElements();
	cout << "\nsecond array is this : ";
	for (int i = 0; i < 5; i++) {
		cout << arr[i] << " ";
	}
	vector<int> common(0);
	common= l.arrayIntersection(arr, 5);
	cout << "\nintersected array is : ";
	for (auto& i : common) {
		cout << i << " ";
	}

	////subarray
	cout << "\n\nsubarray part : \n";
	cout << "\noriginal array is : ";
	l.displayElements();
	int arr2[3] = { 1,2,3 };
	cout << "\nsub array is this : ";
	for (int i = 0; i < 3; i++) {
		cout << arr2[i] << " ";
	}
	if (l.findSubArray(arr, 3)) {
		cout << "\nsubarray is present in original array";
	}
	else {
		cout << "\nsubarray is not present in original array";
	}

	//prime count
	cout << "\n\nprime count : \n";
	cout << "\noriginal array is : ";
	l.displayElements();
	l.primecount();

	//distinct prime
	cout << "\n\ndistinct prime : \n";
	cout << "\noriginal array is : ";
	l.displayElements();
	vector<int> prime(0);
	prime = l.distintPrime();
	cout << "\ndistinct prime are : ";
	for (auto& i : prime) {
		cout << i << " ";
	}

	mylist<int> b;
	b.insert(1);
	b.insert(1);
	b.insert(0);
	b.insert(1);
	b.insert(0);
	b.insert(1);
	b.insert(1);
	b.insert(0);
	b.insert(1);
	b.LongestEqualBinary();
}