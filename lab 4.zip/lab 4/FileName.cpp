#include<iostream>
using namespace std;
class mystack {
public:
	int* arr;
	int maxsize;
	int top;
	mystack() {
		maxsize = 10;
		top = -1;
		arr = new int[maxsize];
	}
	virtual void push(int value) = 0;
	virtual void pop() = 0;
};
class stack :public mystack {

public:
	stack() = default;
	stack(stack& s) {
		this->maxsize = s.maxsize;
		this->top = s.top;
		this->arr = new int[maxsize];
		for (int i = 0; i <= top; i++) {
			this->arr[i] = s.arr[i];
		}
	}
	bool empty() {
		if (top == -1) {
			cout << "Stack is empty" << endl;
			return true;
		}
		else {
			cout << "Stack is not empty" << endl;
			return false;
		}
	}
	bool full() {
		if (top == maxsize - 1) {
			cout << "Stack is full" << endl;
			return true;
		}
		else {
			cout << "Stack is not full" << endl;
			return false;
		}
	}
	void push(int value) {
		if (full()) {
			cout << "Stack Overflow" << endl;
			return;
		}
		arr[++top] = value;
	}
	void pop() {
		if (empty()) {
			cout << "Stack Underflow" << endl;
			return;
		}
		cout << "Popped element: " << arr[top--] << endl;
	}
	int size() {
		return top + 1;
	}
	int peek() {
		if (empty()) {
			cout << "Stack is empty" << endl;
			return -1;
		}
		return arr[top];
	}
	void display() {
		if (empty()) {
			cout << "Stack is empty" << endl;
			return;
		}
		cout << "Stack elements: ";
		for (int i = 0; i <= top; i++) {
			cout << arr[i] << " ";
		}
		cout << endl;
	}
	void count_even_odd() {
		int even_count = 0, odd_count = 0;
		if (empty()) {
			cout << "Stack is empty" << endl;
			return;
		}
		for (int i = 0; i <= top; i++) {
			if (arr[i] % 2 == 0) {
				even_count++;
			}
			else {
				odd_count++;
			}
		}
		cout << "Even count: " << even_count << endl;
		cout << "Odd count: " << odd_count << endl;
	}
	void count_sum_even() {
		int sum = 0;
		if (empty()) {
			cout << "Stack is empty" << endl;
			return;
		}
		for (int i = 0; i <= top; i++) {
			if (arr[i] % 2 == 0) {
				sum += arr[i];
			}
		}
		cout << "Sum of even elements: " << sum << endl;
	}
	void count_sum_odd() {
		int sum = 0;
		if (empty()) {
			cout << "Stack is empty" << endl;
			return;
		}
		for (int i = 0; i <= top; i++) {
			if (arr[i] % 2 != 0) {
				sum += arr[i];
			}
		}
		cout << "Sum of odd elements: " << sum << endl;
	}
	~stack() {
		delete[]arr;
	}
};
int main() {
	stack s1;
	cout << "\nHere is the menue : ";

	int choice, value;
	while (true) {
		cout << "\n1. Push\n2. Pop\n3. Size\n4. Peek\n5. Display\n6. Count Even and Odd\n7. Count Sum of Even\n8. Count Sum of Odd\n9. Exit" << endl;
		cout << "\nEnter your choice: ";
		cin >> choice;
		switch (choice) {
		case 1:
			cout << "Enter value to push: ";
			cin >> value;
			s1.push(value);
			break;
		case 2:
			s1.pop();
			break;
		case 3:
			cout << "Size of stack: " << s1.size() << endl;
			break;
		case 4:
			cout << "Top element: " << s1.peek() << endl;
			break;
		case 5:
			s1.display();
			break;
		case 6:
			s1.count_even_odd();
			break;
		case 7:
			s1.count_sum_even();
			break;
		case 8:
			s1.count_sum_odd();
			break;
		case 9:
			exit(0);
		default:
			cout << "Invalid choice" << endl;
		}
	}

}
